#!/bin/bash

i=1
let i++
echo $i

j=1
sum=`expr $j + 5` # + 左右要加空格
echo $sum
