#!/bin/bash

read -p "请收入姓名:" -t 3 name
echo $name
