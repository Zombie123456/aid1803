#!/bin/bash

for i in a b c d
do
    echo $i
done
