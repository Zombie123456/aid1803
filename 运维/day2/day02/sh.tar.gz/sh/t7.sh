#!/bin/bash

for i in $(seq 5)
do
    echo $i
done
