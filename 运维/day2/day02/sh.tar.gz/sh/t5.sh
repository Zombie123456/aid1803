#!/bin/bash

read -p "请输入第一个数字:" num1
read -p "请输入第二个数字:" num2

if [ $num1 -gt $num2 ];then
    echo "$num1>$num2"
elif [ $num1 -lt $num2 ];then
    echo "$num1<$num2"
else
    echo "$num1=$num2"
fi
