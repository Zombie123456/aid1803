#!/bin/bash

cd
mkdir -p AID18/mydir1
