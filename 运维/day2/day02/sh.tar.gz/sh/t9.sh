#!/bin/bash

for((i=20;i<=47;i++))
do
    if [ `expr $i % 2` -eq 0 ];then
        echo $i
    fi
done
