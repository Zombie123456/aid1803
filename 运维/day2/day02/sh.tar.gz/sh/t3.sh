#!/bin/bash

read -p "请输入姓名:" -t 5 name
echo '变量$name的值是：'$name

